package com.ust.pms.controller;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ust.pms.model.Mail;
import com.ust.pms.service.MailService;
import com.ust.pms.util.UserUtil;

@Controller
//@RequestMapping("mail")
public class MailController {
	@Autowired
	private MailService mailService;

	@RequestMapping(value="/send",method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.put("mail", new Mail());
		return "mailForm";
	}
	
	@RequestMapping(value = "/send", method = RequestMethod.POST)
	public String send( @ModelAttribute("mail") Mail mail, ModelMap modelMap) throws Exception {
		try {
			
			  String content = "Name: " + mail.getName();
			  content += "<br>Phone: " + mail.getPhone();
			  content += "<br>Address: " + mail.getAddress();
			  content += "<br>Subject: " + mail.getSubject();
			  content += "<br>Content: " + mail.getContent();
			 
			mailService.send(mail.getEmail(), UserUtil.getUserName(), mail.getSubject(), content);
			modelMap.put("msg", "Done!");
		} catch (Exception e) {
			modelMap.put("msg", e.getMessage());
		}
		return "mailForm";
	}
}
